<footer class="bg-dark text-white">
  <div class="container-fluid">
    <div class="row">
      <section class="col-md-6 mt-5">
        <a href="#"><i class="fas fa-map-marker-alt"></i> Somewhere on Earth</a> <br>
        <a href="#"><i class="fas fa-phone-alt"></i>+45 123 456 789</a><br>
        <a href="#"><i class="fas fa-envelope"></i>support@gmail.com</a><br>
      </section>
      <section class="col-md-6 mt-5 mb-5">
        <h3>About the website</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        <div class="row">
          <div class="col-md-1">
            <div class="icon text-center">
              <a href="#"> <i class="fab fa-facebook-f"></i> </a>
            </div>
          </div>
          <div class="col-md-1">
            <div class="icon text-center">
              <a href="#"> <i class="fab fa-twitter"></i> </a>
            </div>
          </div>
          <div class="col-md-1">
            <div class="icon text-center">
              <a href="#"> <i class="fab fa-tumblr"></i> </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</footer>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
<script src="js/main.js" charset="utf-8"></script>
</body>
</html>
