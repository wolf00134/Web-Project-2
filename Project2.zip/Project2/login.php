<?php
  include 'config.php';
  include 'func/account.php';
  include 'includes/header.php';
?>
<div class="card text-center">
  <?php if (isset($errorMsg)): ?>
     <div class="alert alert-danger" role="alert">
       <?php echo $errorMsg; ?>
     </div>
   <?php endif; ?>
  <div class="card-body">
    <h1>Login</h1>
    <hr>
    <form class="" action="login.php" method="post">
      <label for="username">Username</label>
      <input type="text" name="name" class="form-control" placeholder="Type your username" value="<?php if (isset($name)) { echo htmlspecialchars($name);} ?>">
      <p class="text-danger error"><?php if(isset($errors['login_username'])) {echo $errors['login_username'];} ?></p>
      <label for="password">Password</label>
      <input type="password" name="password" class="form-control" placeholder="Type your password" value="">
      <p class="error"><?php if(isset($errors['login_password'])) {echo $errors['login_password'];} ?></p>
      <button type="submit" name="login" class="btn btn-block">LOGIN</button>
    </form>
    <h3 class="mt-3">Or sign in using</h3>
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
          <i class="fab fa-facebook-square"></i>
        </div>
        <div class="col-sm-4">
          <i class="fab fa-pinterest-square"></i>
        </div>
        <div class="col-sm-4">
          <i class="fab fa-twitter-square"></i>
        </div>
      </div>
    </div>
    <h3 class="mt-5">Or you can sign up here</h3>
    <a href="signup.php">Sign up</a>
  </div>
</div>
