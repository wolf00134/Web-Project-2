<?php
$host = "localhost";
$user = "root";
$pw = "";
$db = "dbtesting";

// #1: create the conn object
$conn = new mysqli($host, $user, $pw, $db);
