<?php
include 'config.php';
include 'func/postmanager.php';
include 'includes/header.php';
?>
<style>
  <?php
    include 'css/style.css';
  ?>
</style>
 <div class="jumbotron jumbotron-fluid">
   <div class="container">
     <h1>Testing Social Blog 2021</h1>
   </div>
 </div>
   <div class="container-fluid">
     <div class="row">
       <div class="col-md-3 text-center">
         <a href="#"><i class="fab fa-wpexplorer"></i> Explore</a> <br>
         <a href="#"><i class="far fa-bell"></i> Notification</a><br>
         <a href="#"><i class="far fa-envelope"></i>Message</a><br>
         <a href="#"><i class="far fa-bookmark"></i>Bookmark</a><br>
         <a href="#"><i class="fas fa-list"></i>List</a>
       </div>
       <div class="col-md-6">
         <?php if (isset($_GET['login'])): ?>
              <div class="alert alert-success" role="alert">
                You have logged in successfully!
              </div>
            <?php elseif(isset($_GET['logout'])): ?>
            <div class="alert alert-warning" role="alert">
              You have logged out successfully!
            </div>
            <?php endif; ?>
            <div class="row">
              <div class="card form-control text-center ml-5 mr-5">
                <a class="text-dark" href="create.php"><i class="fas fa-pen"></i> What are you thinking? Post something here</a>
              </div>
            </div>
              <?php
              $posts = getPosts(12, $conn);
              outputPosts($posts);
               ?>
              <hr>
       </div>
     </div>
   </div>
 <script src="js/ajax.js" charset="utf-8"></script>
 <?php
 include 'includes/footer.php';
?>
